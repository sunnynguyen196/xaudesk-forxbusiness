"""Deterministic, educational market scenarios from closed M5 candles. No trading orders."""
import statistics, time

def analyze(data):
    bars=data.get('candles') or []
    if len(bars)<20: raise ValueError('Cần tối thiểu 20 nến M5 đã đóng')
    bars=sorted(bars,key=lambda b:b['t']); closes=[float(b['c']) for b in bars]
    price=(float(data['bid'])+float(data['ask']))/2
    highs=[float(b['h']) for b in bars]; lows=[float(b['l']) for b in bars]
    recent=bars[-20:]; prev=bars[-40:-20] if len(bars)>=40 else bars[:-20]
    support=min(float(b['l']) for b in recent); resistance=max(float(b['h']) for b in recent)
    atr=sum(max(float(b['h'])-float(b['l']),abs(float(b['h'])-float(bars[i-1]['c'])),abs(float(b['l'])-float(bars[i-1]['c']))) for i,b in enumerate(bars[-14:],start=len(bars)-14))/14
    fast=sum(closes[-9:])/9; slow=sum(closes[-20:])/20
    deltas=[closes[i]-closes[i-1] for i in range(len(closes)-14,len(closes))]
    gains=sum(max(d,0) for d in deltas)/14; losses=sum(max(-d,0) for d in deltas)/14
    rsi=100 if losses==0 and gains>0 else 50 if losses==0 else 100-100/(1+gains/losses)
    trend='Tăng' if fast>slow and closes[-1]>slow else 'Giảm' if fast<slow and closes[-1]<slow else 'Đi ngang'
    width=max(atr*.3,.01)
    stale=abs(time.time()-int(data['quote_utc']))>30
    return {'price':round(price,2),'spread':round(float(data['ask'])-float(data['bid']),3),'support':round(support,2),'resistance':round(resistance,2),'s2':round(min(float(b['l']) for b in prev),2) if prev else None,'r2':round(max(float(b['h']) for b in prev),2) if prev else None,'atr14':round(atr,2),'rsi14':round(rsi,1),'ma9':round(fast,2),'ma20':round(slow,2),'trend':trend,'stale':stale,'last_close':round(closes[-1],2),'last_bar_utc':bars[-1]['t'],'zone_width':round(width,2),'bull':'Chờ nến M5 đóng trên vùng kháng cự và retest giữ được vùng; không xác nhận bằng tick đơn lẻ.','bear':'Chờ nến M5 đóng dưới vùng hỗ trợ và retest thất bại; không xác nhận bằng tick đơn lẻ.','invalidation':'Kịch bản tăng vô hiệu khi nến M5 đóng lại dưới vùng phá vỡ; kịch bản giảm vô hiệu khi đóng lại trên vùng phá vỡ.','note':'Vùng giá tính từ 20 nến M5 đã đóng, không phải khuyến nghị giao dịch.'}
