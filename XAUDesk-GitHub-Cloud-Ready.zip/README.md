# XAUDesk Cloud — GitHub deployment candidate

Bản này là mã nguồn **chuẩn bị triển khai**, chưa được đẩy lên GitHub hoặc xuất bản trực tuyến.

## Giữ nguyên MT5 Windows
Không sao chép hoặc ghi đè vào thư mục MT5/MCP hiện có. `mt5_agent.py` chỉ là công cụ kết nối cloud tùy chọn, cần cấu hình và chạy riêng một lần nếu muốn truyền dữ liệu MT5. Nếu agent cũ đã gửi được đến đúng API `/api/ingest`, giữ nguyên agent cũ.

## Triển khai
1. Sao lưu repository trước khi cập nhật.
2. Đưa các file trong thư mục này vào root của repository GitHub. **Không** đưa `.env`, API key, mật khẩu hoặc token vào GitHub.
3. Render → New Blueprint → chọn repository → xác nhận `render.yaml`. Blueprint mặc định dùng gói `starter` có thể tính phí.
4. Lấy URL thực tế sau khi trạng thái Live. Mở URL, đăng nhập Basic Auth bằng `XAU_DASH_USER` / `XAU_DASH_PASSWORD` được cấu hình trong Render.
5. Chỉ khi đã kiểm tra API và bảo mật mới cấu hình agent Windows gửi `XAU_CLOUD_URL` và `XAU_INGEST_TOKEN` qua HTTPS.

## Tin tức
`/api/news` tự kiểm tra trang công khai `https://t.me/s/vnwallstreet` theo chu kỳ 120 giây khi có yêu cầu đến API. Bộ lọc dựa trên từ khóa và giải thích có điều kiện, không sử dụng AI và không khẳng định tin đã được xác minh độc lập. Website `vnwallstreet.com/#/home` hiện chỉ có liên kết tham khảo vì chưa có API feed được xác minh. Nếu Telegram thay đổi HTML hoặc chặn truy cập, bộ đọc sẽ báo lỗi, không bịa tin.

## Giới hạn cần biết
- Không tự triển khai được bằng GitHub đơn thuần; cần Render hoặc dịch vụ hosting tương đương.
- `XAU_STORE` mặc định là `/tmp`, dữ liệu có thể mất khi dịch vụ khởi động lại; cần lưu trữ bền vững để dùng production.
- `/api/ai` hiện trả thông báo chưa cấu hình; không tự động tiêu hao token.
- Cần kiểm tra trên Windows với MT5 thật và thử nghiệm truy cập HTTPS sau khi deploy.
- Tránh công khai URL hoặc mật khẩu dashboard.
